package mqtt;

public class Cliente {

    public static void main(String[] args) {

        Subscriber client = new Subscriber();

        client.start();

        while (true) {}

    }

}