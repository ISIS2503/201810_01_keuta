package mqtt;

import org.eclipse.paho.client.mqttv3.*;

public class Subscriber {

	public static final String BROKER_URL = "tcp://172.24.42.36:8083";
	private MqttClient client;

	public Subscriber() {

		String clientId = "cliente";
		try {
			client = new MqttClient(BROKER_URL, clientId);
		} catch (MqttException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public void start() {

		try {
			client.setCallback(new SubscribeCallback());
			client.connect();
			client.subscribe("baja.puertaabierta");
			client.subscribe("media.sospechosa");
			client.subscribe("alta.nopermitida");
			System.out.println(client.isConnected());
		} catch (MqttException e) {
			e.printStackTrace();
			System.exit(1);
		}

	}

}